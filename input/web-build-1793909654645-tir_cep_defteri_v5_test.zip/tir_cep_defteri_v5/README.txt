TIR CEP DEFTERİ V5 TEST PROTOTİPİ

index.html dosyasını Chrome ile açın.
Veriler aynı tarayıcıda localStorage içinde saklanır.
Bu bir arayüz prototipidir; gerçek sunucu, güvenli giriş, çoklu telefon senkronizasyonu, sürekli arka plan GPS ve canlı harita içermez.
